import math

x = 10

def my_sin(theta):
    theta = math.fmod(theta + math.pi, 2 * math.pi) - math.pi
    result = 0
    termsign = 1
    power = 1

    for i in range(x):
        result += (math.pow(theta, power) / math.factorial(power)) * termsign
        termsign *= -1
        power += 2
    return result

def my_cos(theta):
    theta = math.fmod(theta + math.pi, 2 * math.pi) - math.pi
    result = 0
    termsign = 1
    power = 0

    for i in range(x):
        result += (math.pow(theta, power) / math.factorial(power)) * termsign
        termsign *= -1
        power += 2
    return result

def my_tan(theta):
    return my_sin(theta) / my_cos(theta)

def my_atan(theta):
    #theta = math.fmod(theta + math.pi, 2 * math.pi) - math.pi
    if theta > (-1) and theta < (1):
        return my_atan_working(theta)
    result = 0
    termsign = 1
    power = 1

    for i in range(x):
        result += (1 / (math.pow(theta, power)) * power) * termsign #TOTO NIE JE KONSTANTA V MENOVATELI, PROBLEM
        termsign *= -1
        power += 2

    if theta > 0:
        result = (math.pi/2) - result
    else:
        result = - (math.pi / 2) - result
    return result

def my_atan_working(theta):
    #theta = math.fmod(theta + math.pi, 2 * math.pi) - math.pi
    result = 0
    termsign = 1
    power = 1

    for i in range(x):
        result += ((math.pow(theta, power)) / power) * termsign
        termsign *= -1
        power += 2

    return result

# print("Sinus")
# print(my_sin(101))
# print(math.sin(101))
# print()
# print()
#
# print("Cosinus")
# print(my_cos(101))
# print(math.cos(101))
# print()
# print()
#
# print("Tang")
# print(my_tan(101))
# print(math.tan(101))
# print()
# print()

print("Atang")
print(my_atan(-21))
print(math.atan(-21))
s01 - subjekt sa nehybe
s09 - subjekty kracaju na otvorenej ploche
s19 - hraju basketbal (teda beh, statie, atd)
s01_xacc - data z akcelerometra v x-ovej osy
s01_yacc - data z akcelerometra v y-ovej osy
atd.